export class CreateGateDto {
  name: string;
  date: Date;
  sum: number;
  count: number;
  day: number;
}

export class UpdateGateDto {
  count: number;
}

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GateController } from './gate/gate.controller';
import { GateService } from './gate/gate.service';
import { GateModule } from './gate/gate.module';
import { Gate } from './gate/entities/gate.entity';
import { UserController } from './user/user.controller';
import { UserService } from './user/user.service';
import { UserModule } from './user/user.module';
import { User } from './user/entities/user.entity';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'mssql',
      host: 'localhost',
      port: 1433,
      username: 'gofogo',
      password: '1',
      database: 'SamsungClicker',
      entities: [Gate, User],
      synchronize: true,
      options: { encrypt: false },
    }),
    GateModule,
    UserModule,
  ],
})
export class AppModule {}

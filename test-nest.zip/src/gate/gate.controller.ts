import {
  Body,
  Controller,
  Get,
  HttpStatus,
  Param,
  Post,
  Res,
} from '@nestjs/common';
import { Response } from 'express';
import { CreateGateDto, UpdateGateDto } from './dtos/GateDto';
import { GateService } from './gate.service';

@Controller('gate')
export class GateController {
  constructor(private gateService: GateService) {}

  // 전체리스트+토탈합
  @Get('')
  async find(@Res() res: Response) {
    const gates = await this.gateService.findAll();
    let allTotal = 0;
    gates.forEach((a) => (allTotal += a.sum));
    return res
      .status(HttpStatus.OK)
      .json([...gates, { id: 0, name: '', num: 0, sum: allTotal }]);
  }

  //토탑
  @Get('total')
  async getTotal(@Res() res: Response) {
    const gates = await this.gateService.findAll();
    let all = 0;
    gates.forEach((a) => (all += a.sum));
    return res.status(HttpStatus.OK).json(all);
  }

  //단일 게이트 조회+total
  @Get('day')
  async findOne(@Res() res: Response) {
    const gates = await this.gateService.findAll();
    const item = await this.gateService.findDay();

    let all = 0;
    gates.forEach((a) => (all += a.sum));

    return res.status(HttpStatus.OK).json({ ...item, total: all });
  }

  // count ++
  @Post()
  update(@Body() updateGateDto: UpdateGateDto, @Res() res: Response) {
    console.log(updateGateDto);

    this.gateService.modify(updateGateDto);
    return res.status(HttpStatus.OK).send();
  }

  //게이트등록
  @Post('add')
  create(@Body() createGateDto: CreateGateDto, @Res() res: Response) {
    console.log(createGateDto);
    this.gateService.create(createGateDto);
    return res.status(HttpStatus.OK).send();
  }
}
